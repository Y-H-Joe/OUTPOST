#ifndef __INDEX_VERSION_INFO_HPP__
#define __INDEX_VERSION_INFO_HPP__

#include "cereal/archives/json.hpp"
#include "cereal/types/vector.hpp"

class IndexVersionInfo {};

#endif //__INDEX_VERSION_INFO_HPP__
